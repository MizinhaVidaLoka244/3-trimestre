## Cores

```css
:root {
    --text-color: #DBE4EF;
    --card-front-color: #144480;
    --card-back-color: #00F4BF;
}
```

> Para mais cores

- https://colorhunt.co/
- https://color.adobe.com/pt/create/color-wheel

## Para fontes
https://fonts.google.com/
